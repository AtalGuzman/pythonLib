def saludar():
	print("Hola soy un modulo")
	return
	
def despedir():
	print "Adios"
	return 
	
def pregunta():
	print "Camo estas?"

def responder():
	print "bien"